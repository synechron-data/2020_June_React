import React, { Component } from 'react';

class ControlledVsUncontrolledComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { name: "Synechron" };
        this.handleChange = this.handleChange.bind(this);
        this.handleClick = this.handleClick.bind(this);
    }

    handleChange(e) {
        this.setState({ name: e.target.value });
    }

    handleClick(e) {
        // console.log(this.refs);
        this.setState({ name: this.refs.t1.value });
    }

    render() {
        return (
            <div>
                <div className="text-center">
                    <h3 className="text-info">Controlled & Uncontrolled Component</h3>
                </div>

                {/* <input type="text" />
                <input type="text" defaultValue={this.state.name}/>
                <input type="text" value={this.state.name} readOnly/>
                <input type="text" value={this.state.name} /> */}

                {/* <input type="text" value={this.state.name} onChange={this.handleChange} />
                <h2 className="text-info">Name is: {this.state.name}</h2> */}

                <input type="text" defaultValue={this.state.name} ref="t1" />
                <h2 className="text-info">Name is: {this.state.name}</h2>
                <button className="btn btn-primary" onClick={this.handleClick}>Click</button>
            </div>
        );
    }
}

export default ControlledVsUncontrolledComponent;