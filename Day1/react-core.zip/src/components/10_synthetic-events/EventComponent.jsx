import React, { Component } from 'react';

class EventComponent extends Component {
    constructor(props) {
        super(props);
        this.handleClick3 = this.handleClick3.bind(this);
    }

    handleClick1(e) {
        console.log("event: ", e);
        console.log("this: ", this);
        e.preventDefault();
    }

    handleClick2(e) {
        console.log("event: ", e);
        console.log("this: ", this);
        e.preventDefault();
    }

    handleClick3(e) {
        console.log("event: ", e);
        console.log("this: ", this);
        e.preventDefault();
    }

    handleClick4(name, e) {
        console.log("event: ", e);
        console.log("this: ", this);
        console.log("name: ", name);
        e.preventDefault();
    }

    render() {
        return (
            <div>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick1}>Click One</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick2.bind(this)}>Click Two</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick3}>Click Three</a>
                <br />
                <a href="http://www.google.com" onClick={this.handleClick4.bind(this, "Synechron")}>Click Four</a>
                <br />
                <a href="http://www.google.com" onClick={
                    function (e) {
                        console.log("event: ", e);
                        console.log("this: ", this);
                        e.preventDefault();
                    }
                }>Click Five - Anonymous Function</a>
                <br />
                <a href="http://www.google.com" onClick={
                    (function (e) {
                        console.log("event: ", e);
                        console.log("this: ", this);
                        e.preventDefault();
                    }).bind(this)
                }>Click Six - Anonymous Function</a>
                <br />
                <a href="http://www.google.com" onClick={
                    (e) => {
                        console.log("event: ", e);
                        console.log("this: ", this);
                        e.preventDefault();
                    }
                }>Click Seven - Arrow Function</a>
                <br />
                <a href="http://www.google.com" onClick={
                    (e) => {
                        this.handleClick3(e);
                    }
                }>Click Eight - Arrow Function</a>
                 <br />
                <a href="http://www.google.com" onClick={
                    (e) => {
                        this.handleClick4("Manish", e);
                    }
                }>Click Nine - Arrow Function</a>
            </div>
        );
    }
}

export default EventComponent;