/* eslint-disable */
import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log("State: ", this.state);
        console.log("Props: ", this.props);
        return (
            <div>
                <h2 className="text-info">Using Class Syntax</h2>
            </div>
        );
    }
}

// Functional / Stateless / Presentational
const ComponentTwo = () => {
    // console.log("State: ", this.state);
    // console.log("Props: ", this.props);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentThree = (props) => {
    console.log("Props: ", props);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentFour = ({ id, name }) => {
    console.log("Id: ", id);
    console.log("Name: ", name);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};


const ComponentFive = ({ id, name, ...address }) => {
    console.log("Id: ", id);
    console.log("Name: ", name);
    console.log("Address: ", address);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

class ClassVsFunctionalComponent extends Component {
    render() {
        return (
            <div>
                {/* <ComponentOne /> */}
                {/* <ComponentTwo /> */}
                {/* <ComponentThree id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                {/* <ComponentFour id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                <ComponentFive id={1} name={"Manish"} city={"Pune"} state={"MH"} />
            </div>
        );
    }
}

export default ClassVsFunctionalComponent;