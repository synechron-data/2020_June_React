import React, { Component } from 'react';

import {card} from './ComponentTwo.module.css';

class ComponentTwo extends Component {
    render() {
        return (
            <h1 className={`text-success ${card}`}>Hello from Component Two</h1>
        );
    }
}

export default ComponentTwo;