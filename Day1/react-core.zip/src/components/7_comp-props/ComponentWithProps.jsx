import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);

        // this.state = { id: 1 };
        // this.props = { id: 1 };         // Warning - Props cannot be initialized
        // this.props.name = "Abhijeet";      // Error - Props are readonly

        // Reference Copy
        // this.state = this.props;
        // this.state.name = "Abhijeet";       // Error - Props are readonly

        // Shallow Copy
        // this.state = Object.assign({}, this.props);     // ECMASCRIPT 2015 - Object.assign
        // this.state = { ...this.props };     // ECMASCRIPT 2018 - Object Spread

        // Deep Copy
        this.state = JSON.parse(JSON.stringify(this.props));

        // Deep Copy With Functions (Methods) - immutability-helper

        this.state.name = "Abhijeet";
        // this.state.address = { city: "Mumbai" };
        this.state.address.city = "Mumbai"

        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);
        return (
            <div>
                <h2 className="text-info">Component with Props</h2>
            </div>
        );
    }
}

export default ComponentWithProps;