// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // return "Hello";
//         // return 1000;
//         // return true;
//         // return Symbol("Hello");
//         // return { id: 1 };       Not Allowed to return objects
//     }
// }

// export default HelloComponent;

// -------------------------------------------------

// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// -------------------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// -------------------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </div>   // return only one JSX Element
//         );
//     }
// }

// export default HelloComponent;

// // ------------------------------------------------- Class Syntax - Stateful Components / Container Components

// import React, { Component } from 'react';

// // class HelloComponent extends Component {
// //     render() {
// //         return (
// //             <>
// //                 <h1 className="abc">Hello World!</h1>
// //                 <h1 className="abc">Hello World Again!</h1>
// //             </>   // returning React Fragment
// //         );
// //     }
// // }

// class HelloComponent extends Component {
//     render() {
//         return (
//             <React.Fragment>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </React.Fragment>   // returning React Fragment
//         );
//     }
// }

// export default HelloComponent;

// ------------------------------------------------- Function Syntax - Stateless Components / Presentational Components

import React from 'react';

// function HelloComponent() {
//     return (
//         <React.Fragment>
//             <h1 className="abc">Hello World! - Using Function Declaration</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </React.Fragment>   // returning React Fragment
//     );
// }

// const HelloComponent = function () {
//     return (
//         <React.Fragment>
//             <h1 className="abc">Hello World! - Using Anonymous Function</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </React.Fragment>   // returning React Fragment
//     );
// }

// const HelloComponent = () => {
//     return (
//         <React.Fragment>
//             <h1 className="abc">Hello World! - Using Arrow Function</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </React.Fragment>   // returning React Fragment
//     );
// }

const HelloComponent = () => (
    <React.Fragment>
        <h1 className="text-info">Hello World! - Using Single line Arrow Function</h1>
        <h1 className="abc">Hello World Again!</h1>
    </React.Fragment>   // returning React Fragment
);

export default HelloComponent;