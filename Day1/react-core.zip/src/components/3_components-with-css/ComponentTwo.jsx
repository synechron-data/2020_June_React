import React, { Component } from 'react';

const card2 = {
    margin: "1em",
    paddingLeft: 0,
    border: '2px dashed green'
};

class ComponentTwo extends Component {
    render() {
        return (
            <h1 style={card2} className="text-success">Hello from Component Two</h1>
        );
    }
}

export default ComponentTwo;