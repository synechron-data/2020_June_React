/* eslint-disable */
import React, { Component } from 'react';

import CounterAssignment from '../assignment/CounterAssignment';
import CalculatorAssignment from '../assignment/CalculatorAssignment';
import PropTypesDemo from '../1_prop-types/PropTypesDemo';
import ErrorHandler from '../common/ErrorHandler';
import ListRoot from '../2_list/ListComponent';
import ParentComponent from '../3_lifecycle-demo/DemoComponent';
import AjaxComponent from '../4_ajax/AjaxComponent';
import ContextAPIDemo from '../5_context-api/ContextAPIDemo';
import StateHook from '../6_hooks/StateHook';

class RootComponent extends Component {
    render() {
        return (
            <React.Fragment>
                <ErrorHandler>
                    {/* <CounterAssignment /> */}
                    {/* <CalculatorAssignment /> */}
                    {/* <PropTypesDemo /> */}
                    {/* <ListRoot /> */}
                    {/* <ParentComponent /> */}
                    {/* <AjaxComponent /> */}
                    {/* <ContextAPIDemo /> */}
                    <StateHook />
                </ErrorHandler>
            </React.Fragment>
        );
    }
}

export default RootComponent;