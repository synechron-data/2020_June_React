import React, { Component } from 'react';
import PropTypes from 'prop-types';

const ListItem = ({ item }) => {
    return <li className="list-group-item">{item.name}</li>;
}

const ListComponent = ({ children, items }) => {
    var listItems = items.map((item, index) => {
        return <ListItem key={index} item={item} />;
    });

    return (
        <React.Fragment>
            {children}
            <ul className="list-group">
                {listItems}
            </ul>
        </React.Fragment>
    );
};

// const ListComponent = (props) => {
//     var listItems = props.items.map((item, index) => {
//         return <ListItem key={index} item={item} />;
//     });

//     return (
//         <React.Fragment>
//             {props.children}
//             <ul className="list-group">
//                 {listItems}
//             </ul>
//         </React.Fragment>
//     );
// };

ListComponent.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object).isRequired
};

class ListRoot extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        }
    }

    render() {
        return (
            <div>
                <ListComponent items={this.state.employees}>
                    <h1>Employees List</h1>
                </ListComponent>
            </div>
        );
    }
}

export default ListRoot;