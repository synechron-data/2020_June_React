import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import { BrowserRouter } from 'react-router-dom';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<BrowserRouter>
    <RootComponent />
</BrowserRouter>, document.getElementById('root'));
