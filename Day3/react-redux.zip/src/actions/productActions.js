import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/product.service';
import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { message: msg, flag: false }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { message: msg, flag: true, data: products }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { message: msg, flag: true, data: [] }
    };
}

// A thunk is a function that returns another function that takes parameters dispatch
export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Product Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            setTimeout(() => {
                dispatch(loadProductsSuccess(products, "Product Request Completed Successfully"))
            }, 5000);
        }, (eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

function insertProductsSuccess(product, msg) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: { message: msg, flag: true, data: product }
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        productsAPIClient.insertProduct(product).then((insertedProduct) => {
            dispatch(insertProductsSuccess(insertedProduct, "Record Inserted Successfully"));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

function updateProductsSuccess(product, msg) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: { message: msg, flag: true, data: product }
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        productsAPIClient.updateProduct(product).then((updatedProduct) => {
            dispatch(updateProductsSuccess(updatedProduct, "Record Updated Successfully"));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}


function deleteProductsSuccess(product, msg) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: { message: msg, flag: true, data: product }
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(product).then(() => {
            dispatch(deleteProductsSuccess(product, "Record Deleted Successfully"));
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}