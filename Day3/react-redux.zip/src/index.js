// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';
// import { BrowserRouter } from 'react-router-dom';
// import { Provider } from 'react-redux';

// import RootComponent from './components/root/RootComponent';
// import configureStore from './store/configureStore';

// const appStore = configureStore();
// // const appStore = configureStore({counterReducer: 1000});
// // console.log(appStore);
// // console.log(appStore.getState());

// ReactDOM.render(<Provider store={appStore}>
//     <BrowserRouter>
//         <RootComponent />
//     </BrowserRouter>
// </Provider>, document.getElementById('root'));

// --------------------------------------------------------------
import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';

import RootComponent from './components/root/RootComponent';
import configureStore from './store/configureStore';
import history from './history';

const appStore = configureStore();

ReactDOM.render(<Provider store={appStore}>
    <Router history={history}>
        <RootComponent />
    </Router>
</Provider>, document.getElementById('root'));
