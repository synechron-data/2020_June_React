import * as actionTypes from '../actions/actionTypes';
import initialState from './initialState';

const productReducer = (state = initialState.productsData, action) => {
    switch (action.type) {
        case actionTypes.LOAD_PRODUCTS_REQUESTED:
        case actionTypes.LOAD_PRODUCTS_FAILED:
            return {
                products: [...state.products],
                status: action.payload.message,
                flag: action.payload.flag
            };
        case actionTypes.LOAD_PRODUCTS_SUCCESS:
            return {
                products: [...action.payload.data],
                status: action.payload.message,
                flag: action.payload.flag
            };
        case actionTypes.INSERT_PRODUCT_SUCCESS:
            return {
                products: [...state.products, { ...action.payload.data }],
                status: action.payload.message,
                flag: action.payload.flag
            };
        case actionTypes.UPDATE_PRODUCT_SUCCESS:
            var itemIndex = state.products.findIndex(p => p.id === parseInt(action.payload.data.id));
            state.products.splice(itemIndex, 1, { ...action.payload.data });
            return {
                products: [...state.products],
                status: action.payload.message,
                flag: action.payload.flag
            };
        case actionTypes.DELETE_PRODUCT_SUCCESS:
            return {
                products: [...state.products.filter(p => p.id !== parseInt(action.payload.data.id))],
                status: action.payload.message,
                flag: action.payload.flag
            };
        default:
            return state;
    }
}

export default productReducer;