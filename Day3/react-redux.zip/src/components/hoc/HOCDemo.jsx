// A higher-order component is a function that takes a component and returns a new component.

import React, { Component } from 'react';

class HOCDemo extends Component {
    render() {
        return (
            <div>
                <h1 className="text-info">Higher Order Component</h1>
                <h2 className="text-success">Some Data, added by HOC: {this.props.data}</h2>
            </div>
        );
    }
}

var obj = {
    data: "Hello from HOC"
};

var MyHOC = InputComponent => class extends React.Component {
    componentDidMount() {
        this.setState({ data: obj.data });
    }

    render() {
        return <InputComponent {...this.props} {...this.state} />
    }
};

// export default HOCDemo;
const enhancedHOCDemo = MyHOC(HOCDemo)
export default enhancedHOCDemo; 
