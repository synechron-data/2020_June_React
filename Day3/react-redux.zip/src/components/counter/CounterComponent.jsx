import React from 'react';

const CounterComponent = (props) => {
    return (
        <React.Fragment>
            <div className="row">
                <h1 className="text-info">Counter Component</h1>
            </div>
            <div className="row">
                <div className="col-4">
                    <h2 className="text-info">Count: {props.count}</h2>
                </div>
                <div className="col-1">
                    <button className="btn btn-info btn-block" onClick={
                        (e) => {
                            props.inc(2);
                        }
                    }>
                        +
                    </button>
                </div>
                <div className="col-1">
                    <button className="btn btn-info btn-block"  onClick={
                        (e) => {
                            props.dec(2);
                        }
                    }>
                        -
                    </button>
                </div>
                <div className="col-1">
                    <button className="btn btn-info btn-block"  onClick={
                        (e) => {
                            props.mul(2);
                        }
                    }>
                        *
                    </button>
                </div>
            </div>
        </React.Fragment >
    );
};

export default CounterComponent;