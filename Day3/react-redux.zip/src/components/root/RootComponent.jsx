/* eslint-disable */
import React, { Component } from 'react';

import ErrorHandler from '../common/ErrorHandler';
import NavigationComponent from '../bs-nav/NavigationComponent';

class RootComponent extends Component {
    render() {
        return (
            <React.Fragment>
                <ErrorHandler>
                    <NavigationComponent />
                </ErrorHandler>
            </React.Fragment>
        );
    }
}

export default RootComponent;